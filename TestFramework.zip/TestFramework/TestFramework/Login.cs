﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;
using OpenQA.Selenium.IE;
using System.Threading;
using OpenPop.Mime;
using OpenPop.Pop3;
using TestFramework.EmailHelper;

namespace TestFramework
{
    [TestFixture(typeof(FirefoxDriver))]
    //[TestFixture(typeof(InternetExplorerDriver))]
    //[TestFixture(typeof(ChromeDriver))]
    public class BlogTest<TWebDriver> where TWebDriver : IWebDriver, new()
    {
        IWebDriver driver;

        [SetUp]
        public void Initialize()
        {
            driver = new TWebDriver();
        }

        [Test]
        public void Login()
        {
            //Navigate
            driver.Url = "http://demoip.enadoc.com";

            //Terms and conditions
            driver.FindElement(By.XPath(".//*[@id='mainLoginTermsCondition']")).Click();
            Thread.Sleep(100);
            driver.FindElement(By.XPath(".//*[@id='Button2']")).Click();
            Thread.Sleep(2000);

            //Forgot password
            driver.FindElement(By.XPath(".//*[@id='forgotpasswordLinkButton']")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath(".//*[@id='txtUserName']")).SendKeys("enado119@gmail.com");
            driver.FindElement(By.XPath(".//*[@id='nextButton']")).Click();

            Thread.Sleep(15000);

            //Read email
            ReadEmailHelper readEmailHelper = new ReadEmailHelper();
            var tempPwd = readEmailHelper.ReadEmails("pop.gmail.com", "995", "enado119@gmail.com", "0383382153bit", "true");
            //driver.FindElement(By.XPath(".//*[@id='txtOldPassword']")).SendKey;
            Thread.Sleep(3000);



            //driver.FindElement(By.XPath(".//*[@id='backButton']")).Click();
            //Thread.Sleep(5000);

            //Login
            //driver.FindElement(By.XPath(".//*[@id='loginUsernameTextTox']")).SendKeys("damidund@gmail.com");
            //driver.FindElement(By.XPath(".//*[@id='loginPasswordTextTox']")).SendKeys("1");

            //driver.FindElement(By.XPath(".//*[@id='btnLogin']")).Click();
            //Thread.Sleep(10000);

            //Tag search
            //tagSearch();

            //createLibrary();
        }


        public void tagSearch()
        {
            driver.FindElement(By.XPath(".//*[@id='textfield']")).Clear();
            driver.FindElement(By.XPath(".//*[@id='textfield']")).SendKeys("scan");
        }

        public void createLibrary()
        {
            driver.FindElement(By.Id("userImagePanel")).Click();
            Thread.Sleep(5000);


            driver.FindElement(By.XPath(".//*[@id='gSettingLink']/a")).Click();
            Thread.Sleep(10000);

            driver.FindElement(By.XPath(".//*[@id='LibraryConfigurations']/span")).Click();
            Thread.Sleep(10000);
            /*driver.FindElement(By.XPath(".//*[@id='PortalDataPortalTextBox']")).SendKeys("STest");
             Thread.Sleep(5000);
             driver.FindElement(By.XPath(".//*[@id='PortalDataSavePortalButton']")).Click();*/


        }

        [TearDown]
        public void FixtureTearDown()
        {
            driver.Close();
        }
    }

}
