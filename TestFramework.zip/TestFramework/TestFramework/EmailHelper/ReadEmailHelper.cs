﻿using OpenPop.Mime;
using OpenPop.Pop3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestFramework.EmailHelper
{
    public class ReadEmailHelper
    {
        List<Email> Emails = new List<Email>();
        public string ReadEmails(string mailServer, string mailServerPort, string mailServerUserName, string mailServerPassword, string useSSL)
        {
            try
            {
                Pop3Client pop3Client;
                pop3Client = new Pop3Client();
                if (pop3Client.Connected)
                    pop3Client.Disconnect();
                pop3Client.Connect(mailServer, Convert.ToInt32(mailServerPort), Convert.ToBoolean(useSSL));
                pop3Client.Authenticate(mailServerUserName, mailServerPassword, AuthenticationMethod.TryBoth);

                Emails = new List<Email>();
                int count = pop3Client.GetMessageCount();


                string lines = "";
                for (int i = count; i > 0; i--)
                {
                    string ID = pop3Client.GetMessageUid(i);

                    Message message = pop3Client.GetMessage(i);
                    DateTime messageDate = message.Headers.DateSent.AddHours(5).AddMinutes(30);
                    if (message.Headers.From.Address == "noreply@post.enadoc.com" && messageDate >= DateTime.Now.AddMinutes(-20)
                        && message.Headers.Subject.Contains("Enadoc password reset"))
                    {
                        lines = message.Headers.DateSent.ToString();


                        var email = new Email
                        {
                            MessageNumber = i,
                            Subject = message.Headers.Subject,
                            DateSent = message.Headers.DateSent.AddHours(5).AddMinutes(30),
                            From =
                                string.Format("<a href = 'mailto:{1}'>{0}</a>", message.Headers.From.DisplayName,
                                              message.Headers.From.Address),
                        };
                        MessagePart body = message.FindFirstHtmlVersion();
                        if (body != null)
                        {
                            email.Body = body.GetBodyAsText();
                        }
                        else
                        {
                            body = message.FindFirstPlainTextVersion();
                            if (body != null)
                            {
                                email.Body = body.GetBodyAsText();

                            }
                        }
                        Emails.Add(email);

                    }
                    break;
                }
                var lastEmail = Emails.First();
                var emailBody = lastEmail.Body;
                string pwd = "";
                pwd = emailBody.Substring(emailBody.IndexOf("Your Verification code is :") + 31, 5);
                return pwd;

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
